from django.core.validators import RegexValidator
from django.db import models
from django.urls import reverse
from django.utils import timezone

from apps.corecode.models import StudentClass

class Student(models.Model):
    STATUS_CHOICES = [("active", "Active"), ("inactive", "Inactive")]
    GENDER_CHOICES = [("male", "Male"), ("female", "Female")]

    current_status = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default="active"
    )
    event_id = models.CharField(max_length=200, unique=True)
    event_name = models.CharField(max_length=200)
    venue = models.CharField(max_length=200)
    capacity = models.CharField(max_length=200, blank=True)
    # gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default="male")
    event_date= models.DateField(default=timezone.now)
    # address = models.ForeignKey(
    #     StudentClass, on_delete=models.SET_NULL, blank=True, null=True
    # )
   

    mobile_num_regex = RegexValidator(
        regex="^[0-9]{10,15}$", message="Entered mobile number isn't in the right format!"
    )
    organizer_mobile_number = models.CharField(
        validators=[mobile_num_regex], max_length=13, blank=True
    )

    # address = models.TextField(blank=True)
    # others = models.TextField(blank=True)
    # passport = models.ImageField(blank=True, upload_to="students/passports/")

    class Meta:
        ordering = ["event_name", "venue", "capacity"]

    # def __str__(self):
    #     return f"{self.event_name} {self.venue} {self.capacity} ({self.event_id})"
    # After removing
    def __str__(self):
        return f"{self.event_name} {self.venue} {self.capacity} ({self.event_id})"


    def get_absolute_url(self):
        return reverse("student-detail", kwargs={"pk": self.pk})

class StudentBulkUpload(models.Model):
    date_uploaded = models.DateTimeField(auto_now=True)
    csv_file = models.FileField(upload_to="students/bulkupload/")
