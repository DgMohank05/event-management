def chatbot():
    print("Hello! I'm your event management assistant. How can I help you today?")

    while True:
        user_input = input("You: ").lower()

        if "create an event" in user_input:
            print("Chatbot: To create an event, click on 3 bars on top left >> Event Management >> Add Event >> Fill in the details >> Add Event.")

        elif "see invoices" in user_input:
            print("Chatbot: To see invoices, click on 3 bars on top left >> Invoices. You will find all your invoices there.")

        elif "listed events" in user_input:
            print("Chatbot: To view listed events and venues, click on 3 bars on top left >> Listed Events. There you can find all the listed events and venues.")

        elif "exit" in user_input:
            print("Chatbot: Goodbye!")
            break

        else:
            print("Chatbot: I'm sorry, I didn't understand that. Can you please ask another question?")

if __name__ == "__main__":
    chatbot()
